from random import randint
from math import gcd


CONDITION = 'Find the greatest common divisor of given numbers.'


def question_and_answer():
    num1 = randint(20, 99)
    num2 = randint(20, 99)
    res = str(gcd(num1, num2))
    return str(f"{num1} {num2}"), res
